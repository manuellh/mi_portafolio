
<div class="container">

    <!-- About Section Heading-->
    <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">About</h2>
    <!-- Icon Divider-->
    <div class="divider-custom">
        <div class="divider-custom-line"></div>
        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
        <div class="divider-custom-line"></div>
    </div>

    <!-- About Section Content-->
    <div class="row">
        <div class="col-lg-4 ms-auto"><p class="lead text-secondary"><?php echo e($misdatos->descripcion); ?></p></div>
        <div class="col-lg-4 me-auto"><p class="lead text-secondary">You can create your own custom avatar for the masthead, change the icon in the dividers, and add your email address to the contact form to make it fully functional!</p></div>
    </div>

    <!-- About Section Button-->
    <div class="text-center mt-4">
        <a class="btn btn-xl btn-outline-secondary " href="#!"><i class="fas fa-download me-2"></i>
        Descargar CV
        </a>
    </div>

</div><?php /**PATH /home/manuel/Laravel/miPortafolio/resources/views/layouts/sections/about.blade.php ENDPATH**/ ?>