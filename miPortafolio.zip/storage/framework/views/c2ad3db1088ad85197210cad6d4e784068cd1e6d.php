<?php $__env->startSection('template_title'); ?>
    <?php echo e($proyecto->name ?? 'Show Proyecto'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Proyecto</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('proyectos.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Nombre:</strong>
                            <?php echo e($proyecto->nombre); ?>

                        </div>
                        <div class="form-group">
                            <strong>Imagen:</strong>
                            <?php echo e($proyecto->imagen); ?>

                        </div>
                        <div class="form-group">
                            <strong>Descripcion:</strong>
                            <?php echo e($proyecto->descripcion); ?>

                        </div>
                        <div class="form-group">
                            <strong>Url:</strong>
                            <?php echo e($proyecto->url); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/manuel/Laravel/miPortafolio/resources/views/proyecto/show.blade.php ENDPATH**/ ?>