<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('habilidad')); ?>

            <?php echo e(Form::text('habilidad', $habilidade->habilidad, ['class' => 'form-control' . ($errors->has('habilidad') ? ' is-invalid' : ''), 'placeholder' => 'Habilidad'])); ?>

            <?php echo $errors->first('habilidad', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('imagen')); ?>

            <?php echo e(Form::text('imagen', $habilidade->imagen, ['class' => 'form-control' . ($errors->has('imagen') ? ' is-invalid' : ''), 'placeholder' => 'Imagen'])); ?>

            <?php echo $errors->first('imagen', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('nivel')); ?>

            <?php echo e(Form::text('nivel', $habilidade->nivel, ['class' => 'form-control' . ($errors->has('nivel') ? ' is-invalid' : ''), 'placeholder' => 'Nivel'])); ?>

            <?php echo $errors->first('nivel', '<div class="invalid-feedback">:message</p>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH /home/manuel/Laravel/miPortafolio/resources/views/habilidade/form.blade.php ENDPATH**/ ?>