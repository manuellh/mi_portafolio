<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Fixed Bootstrap Sidebar</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" >
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
  <link href="<?php echo e(asset('css/sidenavstyle.css')); ?>" rel="stylesheet">
  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</head>
<body>
<!-- partial:index.partial.html -->
<div class="sidebar-container">
  <div class="sidebar-logo">
    Mi Portafolio
  </div>
  <ul class="sidebar-navigation">
    <li class="header">Navigation</li>
    <?php if(Route::has('login')): ?>
        <li>
            <a href="<?php echo e(route('misdatos.index')); ?>">
                <i class="fa fa-user" aria-hidden="true"></i> <?php echo e(__('Mis Datos')); ?>

        </li>
        <li>
            <a href="<?php echo e(route('habilidades.index')); ?>">
                <i class="fa fa-code" aria-hidden="true"></i> <?php echo e(__('Habilidades')); ?>

        </li>
        <li>
            <a href="<?php echo e(route('experiencia.index')); ?>">
                <i class="fa fa-id-badge" aria-hidden="true"></i> <?php echo e(__('Experiencia')); ?>

        </li>
        <li>
            <a href="<?php echo e(route('proyectos.index')); ?>">
                <i class="fa fa-swatchbook" aria-hidden="true"></i> <?php echo e(__('Proyectos')); ?>

        </li>
        <li>
            <a href="<?php echo e(route('hobbies.index')); ?>">
                <i class="fa fa-palette" aria-hidden="true"></i> <?php echo e(__('Hobies')); ?>

        </li>

        <li class="header">Another Menu</li>

        <li>
          <a href="#">
            <i class="fa fa-cog" aria-hidden="true"></i> Settings
          </a>
        </li>
    <?php endif; ?>
  </ul>
</div>

<div class="content-container">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ms-auto flex-nowrap">
          <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>

                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
          </ul>
        </div>
      </div>
    </nav>
  <div class="container-fluid">

    <!-- Main component for a primary marketing message or call to action -->
    <div class="jumbotron">
      <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
      </main>
    </div>

  </div>
</div>
<!-- partial -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

</body>
</html>
<?php /**PATH /home/manuel/Laravel/miPortafolio/resources/views/layouts/dashboard.blade.php ENDPATH**/ ?>