<?php $__env->startSection('template_title'); ?>
    Misdato
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-5">
            <?php $__currentLoopData = $misdatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 25rem;">
                    <img class="card-img-top" src="<?php echo e($data->img); ?>" alt="José Manuel">
                    <div class="card-body">
                        
                        <ul class="list-group">
                            <li class="list-group-item">Nombre: <?php echo e($data->nombre); ?></li>
                            <li class="list-group-item">Edad: <?php echo e($data->edad); ?></li>
                            <li class="list-group-item">Estudios: <?php echo e($data->estudios); ?></li>
                            <li class="list-group-item">Correo: <?php echo e($data->email); ?></li>
                        </ul>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-sm-7">
                

                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span id="card_title">
                                Descripcion
                            </span>
                        </div>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="card-body">
                        <p class="card-text"><?php echo e($data->descripcion); ?></p>
                    </div>
                </div>
                <div class="card mt-4">
                    <div class="card-header">Opciones</div>
                    <div class="card-body">
                    <a class="btn btn-lg btn-success btn-block" href="<?php echo e(route('misdatos.edit',$data->id)); ?>"><i class="fa fa-fw fa-edit"></i> Edit</a>
                    </div>

                </div>
                <?php echo $misdatos->links(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/manuel/Laravel/miPortafolio/resources/views/misdato/index.blade.php ENDPATH**/ ?>