@extends('layouts.dashboard')

@section('content')
<div class="container">
<h1 class="display-1 text-center">Hola</h1>
</div>

@endsection

