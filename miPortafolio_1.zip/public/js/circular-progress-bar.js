$(function() {
  $('.chart').easyPieChart({
    size: 160,
    barColor: "#fff",
    scaleLength: 0,
    lineWidth: 15,
    trackColor: "#148f77",
    lineCap: "circle",
    animate: 2000,
  });
});
